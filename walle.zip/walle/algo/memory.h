#ifndef WALLE_ALGO_MEMORY_H_
#define WALLE_ALGO_MEMORY_H_

#include <walle/config/config.h>

#include<memory>

#endif