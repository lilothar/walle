#ifndef WALLE_ALGO_FUNCTIONAL_H_
#define WALLE_ALGO_FUNCTIONAL_H_
#include <walle/config/config.h>

    #include <functional>
    namespace std{
    using std::placeholders::_1;
    using std::placeholders::_2;
    using std::placeholders::_3;
    using std::placeholders::_4;
    using std::placeholders::_5;
    using std::placeholders::_6;
    using std::placeholders::_7;
    using std::placeholders::_8;
         
    }


#endif
